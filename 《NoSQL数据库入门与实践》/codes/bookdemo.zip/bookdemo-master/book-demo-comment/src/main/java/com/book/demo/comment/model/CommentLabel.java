package com.book.demo.comment.model;

/**
 * @描述 : 评价标签
 * @创建者：liushengsong
 * @创建时间： 2017年2月20日上午11:52:42
 *
 */
public class CommentLabel {

	/** 标签内容 **/
	private String content;

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

}
